(function(){
	window.onload = function(){
		console.log(url);
		// var url = "http://www.alexzfx.com/exportpdf";
		// var url = "http://192.168.100.174:8080";
		// $.ajax({
		// 	url: 'http://192.168.100.174:8080/get_ver_code',
		// 	type: 'GET',
		// 	xhrFields: {
		// 		withCredentials: true
		// 	}
		// })
		// .done(function(res) {
		// 	console.log(res);
		// 	console.log("success");
		// })
		// .fail(function() {
		// 	console.log("error");
		// })
		// .always(function() {
		// 	console.log("complete");
		// });
		
		$("#login").on('click', function(event) {
			event.preventDefault();
			var username = $("#username input").val();
			var password = $("#password input").val();
			var vercode = $("#ver_code input").val();
			console.log(username);
			var json = {
				"username":username,
				"password":password,
				"ver_code":vercode,
			}
			$.ajax({
				url: url + 'login',
				type: 'POST',
				dataType: 'json',
				contentType: "application/json",
				data:JSON.stringify(json)
			})
			.done(function(res) {
				console.log(res);
				console.log("success");
				if(res.ret==0){
					$(window).attr('location','./index/index.html');  
				}
			})
			.fail(function() {
				console.log("error");
			})
			.always(function() {
				console.log("complete");
			});

		});
		document.getElementById("get_ver_code").addEventListener("click",function(){
			this.src = url + 'get_ver_code?time=' + Math.random();
		} ,false )
	}
	
})();